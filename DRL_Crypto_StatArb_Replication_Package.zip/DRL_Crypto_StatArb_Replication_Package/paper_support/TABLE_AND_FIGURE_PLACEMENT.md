# Table and figure placement guide

Use APA sequential numbering in the manuscript.

## Section 4: Data, Methodology, and Experimental Design

- Section 4.2 Asset-Universe Design: Insert Table 1.
- Section 4.2 or 4.3: Insert Figure 1 or Figure 2 if using a conceptual diagram.
- Section 4.6/4.7: Insert action-space and reward equations as native Word equation objects from `results/docx/`.

## Section 5: Empirical Results and Discussion

- Section 5.1 Main Results by Asset Universe: Insert Table 2 and Figure 3.
- Section 5.2 Full Model Comparison Across Universes: Insert Table 3 and Figure 4.
- Section 5.3 Binary Versus Granular Action-Space Results: Insert Table 4 and Figure 5.
- Section 5.4 Robustness Across Random Seeds: Insert Table 5 and Figure 6.

## Appendix

- Appendix Table A1: Seed completion check.
- Appendix Table A2: Universe label crosswalk.
