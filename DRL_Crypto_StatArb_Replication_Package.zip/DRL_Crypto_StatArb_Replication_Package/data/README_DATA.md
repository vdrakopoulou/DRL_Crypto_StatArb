# Data folder

This folder contains the data artifacts available for the replication package.

## What is included

- `source_outputs/modeling_comparison_summary.csv`: trusted main seed-42 source results used to recreate the manuscript tables.
- `source_outputs/robustness_stats_by_model.csv`: updated robustness statistics across seeds 42, 101, and 202.
- `source_outputs/robustness_seed_check.csv`: seed completion check for the robustness tests.
- `source_outputs/robustness_combined_clean.csv`: seed-level robustness source rows, when available.
- `final_tables/`: final manuscript-ready CSV tables.
- `raw_ohlcv/`: placeholder folder for raw Binance 30-minute OHLCV data.

## Raw market data note

The raw Binance 30-minute OHLCV files were not present in the uploaded materials. To keep the package transparent, this replication package includes the asset-universe configuration files and a downloader script: `code/01_download_binance_klines.py`.

Use the downloader to reconstruct raw data from Binance Public Data. After download, store raw CSV files under `data/raw_ohlcv/` using the universe and symbol structure described in `data/raw_ohlcv/README_RAW_DATA.md`.
