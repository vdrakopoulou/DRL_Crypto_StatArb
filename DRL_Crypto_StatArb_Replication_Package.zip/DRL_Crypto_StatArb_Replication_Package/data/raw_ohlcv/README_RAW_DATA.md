# Raw OHLCV data placeholder

Raw Binance 30-minute OHLCV files are not included in this package because they were not present in the uploaded materials and may be large.

Recommended folder layout after download:

```text
data/raw_ohlcv/
  data_original14_recent/
    BTCUSDT_30m.csv
    ETHUSDT_30m.csv
    ...
  data_expanded20_recent/
  data_bitcoin_payment6_recent/
  data_layer1_9_recent/
```

Expected kline columns:

```text
open_time, open, high, low, close, volume, close_time, quote_asset_volume,
number_of_trades, taker_buy_base_asset_volume, taker_buy_quote_asset_volume, ignore
```

The manuscript tables and figures are reproduced from saved summary outputs in `data/source_outputs/`, not from raw OHLCV files.
