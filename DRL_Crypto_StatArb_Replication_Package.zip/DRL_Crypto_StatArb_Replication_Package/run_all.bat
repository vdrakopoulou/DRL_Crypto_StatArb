@echo off
python code\00_validate_inputs.py || exit /b
python code\02_recreate_tables.py || exit /b
python code\03_make_figures.py || exit /b
python code\04_validate_results.py || exit /b
