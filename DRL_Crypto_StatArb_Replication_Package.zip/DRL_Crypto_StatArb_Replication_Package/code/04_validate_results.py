from __future__ import annotations

import csv
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "results" / "tables"
FIGS = ROOT / "results" / "figures"


def read_csv(name: str):
    with (TABLES / name).open(newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def approx(actual: str, expected: float, tol: float = 0.02) -> bool:
    return abs(float(actual) - expected) <= tol


def main() -> int:
    errors = []
    t2 = read_csv("Table2_best_strategy_by_universe_seed42.csv")
    expected_t2 = {
        "Baseline 14-Asset Universe": 30.24,
        "Broad 20-Asset Universe": 3.25,
        "Payment-Coin 6-Asset Universe": 32.26,
        "Layer-1 Platform 9-Asset Universe": -7.83,
    }
    for row in t2:
        exp = expected_t2.get(row["Asset universe"])
        if exp is None or not approx(row["Return (%)"], exp):
            errors.append(f"Unexpected Table 2 return for {row['Asset universe']}: {row['Return (%)']}")

    t5 = read_csv("Table5_updated_robustness_stats.csv")
    pmt = next((r for r in t5 if r["Universe"] == "Payment-Coin 6" and r["Alg."] == "DQN" and r["Action"] == "binary"), None)
    if pmt is None or not approx(pmt["Ret. M (%)"], 16.50):
        errors.append("Unexpected robustness mean for Payment-Coin 6 DQN binary")

    for fig in [
        "figure3_best_total_return_by_universe.png",
        "figure4_return_drawdown_best_strategies.png",
        "figure5_granular_minus_binary_return_delta.png",
        "figure6_robustness_return_ranges.png",
    ]:
        if not (FIGS / fig).exists():
            errors.append(f"Missing figure: {fig}")

    if errors:
        print("Validation failed:")
        for e in errors:
            print(f"  - {e}")
        return 1
    print("Result validation passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
