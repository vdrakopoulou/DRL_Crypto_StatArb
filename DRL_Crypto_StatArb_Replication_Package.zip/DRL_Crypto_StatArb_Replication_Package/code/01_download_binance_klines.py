"""Download Binance Public Data 30-minute klines for the configured asset universes.

This script is provided to reconstruct raw OHLCV data. It requires internet access.
It is not needed to recreate the manuscript tables from the saved summary outputs.

Example:
    python code/01_download_binance_klines.py --universe data_original14_recent --start 2023-01 --end 2025-05
    python code/01_download_binance_klines.py --all --dry-run
"""
from __future__ import annotations

import argparse
import csv
import io
import zipfile
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]
BASE_URL = "https://data.binance.vision/data/spot/monthly/klines"
INTERVAL = "30m"

UNIVERSE_TO_FILE = {
    "data_original14_recent": "assets_original_14.csv",
    "data_expanded20_recent": "assets_expanded_20.csv",
    "data_bitcoin_payment6_recent": "assets_bitcoin_payment_6.csv",
    "data_layer1_9_recent": "assets_layer1_9.csv",
}

KLINE_COLUMNS = [
    "open_time", "open", "high", "low", "close", "volume", "close_time",
    "quote_asset_volume", "number_of_trades", "taker_buy_base_asset_volume",
    "taker_buy_quote_asset_volume", "ignore",
]


def month_range(start: str, end: str) -> list[str]:
    sy, sm = map(int, start.split("-"))
    ey, em = map(int, end.split("-"))
    months = []
    y, m = sy, sm
    while (y, m) <= (ey, em):
        months.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y += 1
            m = 1
    return months


def read_symbols(asset_file: Path) -> list[str]:
    with asset_file.open(newline="", encoding="utf-8") as f:
        return [row["symbol"].strip().upper() for row in csv.DictReader(f)]


def download_zip_csv(symbol_pair: str, month: str) -> list[list[str]]:
    filename = f"{symbol_pair}-{INTERVAL}-{month}.zip"
    url = f"{BASE_URL}/{symbol_pair}/{INTERVAL}/{filename}"
    with urlopen(url, timeout=60) as response:
        payload = response.read()
    with zipfile.ZipFile(io.BytesIO(payload)) as zf:
        csv_name = zf.namelist()[0]
        with zf.open(csv_name) as f:
            text = io.TextIOWrapper(f, encoding="utf-8")
            return list(csv.reader(text))


def write_symbol_csv(out_path: Path, rows: list[list[str]]) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(KLINE_COLUMNS)
        writer.writerows(rows)


def run_for_universe(universe: str, months: list[str], dry_run: bool = False) -> None:
    asset_file = ROOT / "config" / "asset_universes" / UNIVERSE_TO_FILE[universe]
    symbols = read_symbols(asset_file)
    out_dir = ROOT / "data" / "raw_ohlcv" / universe
    for symbol in symbols:
        pair = f"{symbol}USDT"
        combined: list[list[str]] = []
        for month in months:
            filename = f"{pair}-{INTERVAL}-{month}.zip"
            url = f"{BASE_URL}/{pair}/{INTERVAL}/{filename}"
            if dry_run:
                print(url)
                continue
            try:
                rows = download_zip_csv(pair, month)
                combined.extend(rows)
                print(f"Downloaded {pair} {month}: {len(rows)} rows")
            except HTTPError as exc:
                print(f"Warning: {pair} {month} unavailable ({exc.code})")
            except URLError as exc:
                print(f"Warning: network error for {pair} {month}: {exc}")
        if not dry_run and combined:
            write_symbol_csv(out_dir / f"{pair}_{INTERVAL}.csv", combined)
            print(f"Wrote {out_dir / f'{pair}_{INTERVAL}.csv'}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--universe", choices=sorted(UNIVERSE_TO_FILE), help="Universe folder name to download")
    parser.add_argument("--all", action="store_true", help="Download all universes")
    parser.add_argument("--start", default="2023-01", help="Start month YYYY-MM")
    parser.add_argument("--end", default="2025-05", help="End month YYYY-MM")
    parser.add_argument("--dry-run", action="store_true", help="Print URLs without downloading")
    args = parser.parse_args()

    universes = list(UNIVERSE_TO_FILE) if args.all else [args.universe]
    if not universes or universes == [None]:
        parser.error("Use --universe or --all")
    months = month_range(args.start, args.end)
    for universe in universes:
        run_for_universe(universe, months, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
