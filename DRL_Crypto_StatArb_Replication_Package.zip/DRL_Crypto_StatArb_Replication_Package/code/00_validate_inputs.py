from __future__ import annotations

from pathlib import Path
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    ROOT / "config" / "study_config.yaml",
    ROOT / "config" / "universe_crosswalk.csv",
    ROOT / "data" / "source_outputs" / "modeling_comparison_summary.csv",
    ROOT / "data" / "source_outputs" / "robustness_stats_by_model.csv",
    ROOT / "data" / "source_outputs" / "robustness_seed_check.csv",
]

ASSET_FILES = [
    "assets_original_14.csv",
    "assets_expanded_20.csv",
    "assets_bitcoin_payment_6.csv",
    "assets_layer1_9.csv",
]


def count_rows(path: Path) -> int:
    with path.open(newline="", encoding="utf-8-sig") as f:
        return sum(1 for _ in csv.DictReader(f))


def main() -> int:
    missing = [str(p.relative_to(ROOT)) for p in REQUIRED if not p.exists()]
    missing += [f"config/asset_universes/{name}" for name in ASSET_FILES if not (ROOT / "config" / "asset_universes" / name).exists()]
    if missing:
        print("Missing required files:")
        for m in missing:
            print(f"  - {m}")
        return 1

    main_rows = count_rows(ROOT / "data" / "source_outputs" / "modeling_comparison_summary.csv")
    robust_rows = count_rows(ROOT / "data" / "source_outputs" / "robustness_stats_by_model.csv")
    seed_rows = count_rows(ROOT / "data" / "source_outputs" / "robustness_seed_check.csv")
    print("Input validation passed.")
    print(f"Main source rows: {main_rows}")
    print(f"Robustness model rows: {robust_rows}")
    print(f"Robustness seed-check rows: {seed_rows}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
