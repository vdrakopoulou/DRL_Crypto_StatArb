# Code folder

Run scripts from the package root.

Recommended order:

```bash
python code/00_validate_inputs.py
python code/02_recreate_tables.py
python code/03_make_figures.py
python code/04_validate_results.py
```

Optional raw-data download scaffold:

```bash
python code/01_download_binance_klines.py --all --dry-run
python code/01_download_binance_klines.py --all --start 2023-01 --end 2025-05
```

The manuscript tables and figures are reproduced from `data/source_outputs/`, not from raw OHLCV files.
