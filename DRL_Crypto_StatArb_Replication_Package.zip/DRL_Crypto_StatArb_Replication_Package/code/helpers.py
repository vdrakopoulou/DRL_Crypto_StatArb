from __future__ import annotations

import csv
from pathlib import Path
from typing import Dict, Iterable, List, Any

UNIVERSE_ORDER = [
    "Baseline 14",
    "Broad 20",
    "Payment-Coin 6",
    "Layer-1 Platform 9",
]

FOLDER_TO_LABEL = {
    "data_original14_recent": ("Baseline 14-Asset Universe", "Baseline 14"),
    "data_expanded20_recent": ("Broad 20-Asset Universe", "Broad 20"),
    "data_bitcoin_payment6_recent": ("Payment-Coin 6-Asset Universe", "Payment-Coin 6"),
    "data_layer1_9_recent": ("Layer-1 Platform 9-Asset Universe", "Layer-1 Platform 9"),
}

ASSET_UNIVERSES = [
    {
        "Universe label": "Baseline 14-Asset Universe",
        "No. of assets": 14,
        "Assets": "BTC, ETH, BNB, XRP, ADA, SOL, DOT, BCH, LTC, AVAX, ALGO, AAVE, UNI, CAKE",
        "Purpose": "Replication baseline matching the 14-asset cryptocurrency universe.",
    },
    {
        "Universe label": "Broad 20-Asset Universe",
        "No. of assets": 20,
        "Assets": "BTC, ETH, BNB, XRP, ADA, SOL, DOT, BCH, LTC, AVAX, ALGO, AAVE, UNI, CAKE, DOGE, LINK, TRX, XLM, ATOM, FIL",
        "Purpose": "Broad-market extension used to test scalability and asset-set noise.",
    },
    {
        "Universe label": "Payment-Coin 6-Asset Universe",
        "No. of assets": 6,
        "Assets": "BTC, BCH, LTC, DOGE, XRP, XLM",
        "Purpose": "Payment-focused subset used to test whether economically related assets improve cointegration stability.",
    },
    {
        "Universe label": "Layer-1 Platform 9-Asset Universe",
        "No. of assets": 9,
        "Assets": "ETH, BNB, ADA, SOL, DOT, AVAX, ALGO, TRX, ATOM",
        "Purpose": "Blockchain-platform sector subset used to test sector-specific arbitrage performance.",
    },
]


def read_csv(path: Path) -> List[Dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: Iterable[Dict[str, Any]], fieldnames: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})


def to_float(value: Any, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    try:
        return float(value)
    except ValueError:
        return default


def pct(value: Any) -> float:
    return round(to_float(value) * 100, 2)


def rounded(value: Any, digits: int = 2) -> float:
    return round(to_float(value), digits)


def universe_from_row(row: Dict[str, str]) -> str:
    raw = row.get("universe", "") or row.get("data_root", "") or ""
    raw = raw.replace("\\", "/")
    folder = raw.rstrip("/").split("/")[-1]
    if folder in FOLDER_TO_LABEL:
        return FOLDER_TO_LABEL[folder][1]
    return folder or raw


def manuscript_universe(short_label: str) -> str:
    for _, (long_label, short) in FOLDER_TO_LABEL.items():
        if short == short_label:
            return long_label
    return short_label


def strategy_from_label(row: Dict[str, str]) -> str:
    benchmark = row.get("benchmark", "").upper()
    label = row.get("label", "")
    if benchmark == "COIN" or label.upper() == "COIN":
        return "COIN benchmark"
    return label.split("_")[0]


def sort_universe_key(label: str) -> int:
    return UNIVERSE_ORDER.index(label) if label in UNIVERSE_ORDER else 99
