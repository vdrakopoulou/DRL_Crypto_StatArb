from __future__ import annotations

from pathlib import Path
from helpers import (
    ASSET_UNIVERSES,
    FOLDER_TO_LABEL,
    UNIVERSE_ORDER,
    manuscript_universe,
    pct,
    read_csv,
    rounded,
    sort_universe_key,
    strategy_from_label,
    to_float,
    universe_from_row,
    write_csv,
)

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "data" / "source_outputs"
OUT_TABLES = ROOT / "results" / "tables"
OUT_DATA_TABLES = ROOT / "data" / "final_tables"


def model_sort_key(strategy: str) -> int:
    order = {"DQN": 0, "PPO": 1, "A2C": 2, "COIN benchmark": 3}
    return order.get(strategy, 99)


def load_main_rows():
    rows = read_csv(SOURCE / "modeling_comparison_summary.csv")
    normalized = []
    for row in rows:
        universe = universe_from_row(row)
        strategy = strategy_from_label(row)
        action = "benchmark" if strategy == "COIN benchmark" else row.get("action_space", "")
        normalized.append({
            "Universe": universe,
            "Strategy": strategy,
            "Action": action,
            "Return (%)": pct(row.get("total_return")),
            "Sharpe": rounded(row.get("sharpe")),
            "Calmar": rounded(row.get("calmar")),
            "Max DD (%)": pct(row.get("max_drawdown")),
            "Vol. (%)": pct(row.get("annualized_volatility")),
            "Turnover": rounded(row.get("total_turnover"), 1),
        })
    return normalized


def write_both(filename: str, rows, fields):
    for folder in [OUT_TABLES, OUT_DATA_TABLES]:
        write_csv(folder / filename, rows, fields)


def table1():
    fields = ["Universe label", "No. of assets", "Assets", "Purpose"]
    write_both("Table1_asset_universes.csv", ASSET_UNIVERSES, fields)


def table2(main_rows):
    interpretations = {
        "Baseline 14": "Strongest risk-adjusted result.",
        "Broad 20": "Broad expansion did not improve DRL.",
        "Payment-Coin 6": "Highest raw return.",
        "Layer-1 Platform 9": "DRL reduced losses but remained negative.",
    }
    out = []
    for universe in UNIVERSE_ORDER:
        candidates = [r for r in main_rows if r["Universe"] == universe]
        best = max(candidates, key=lambda r: to_float(r["Return (%)"]))
        out.append({
            "Asset universe": manuscript_universe(universe),
            "Strategy": best["Strategy"],
            "Action": best["Action"],
            "Return (%)": best["Return (%)"],
            "Sharpe": best["Sharpe"],
            "Max DD (%)": best["Max DD (%)"],
            "Main interpretation": interpretations[universe],
        })
    fields = ["Asset universe", "Strategy", "Action", "Return (%)", "Sharpe", "Max DD (%)", "Main interpretation"]
    write_both("Table2_best_strategy_by_universe_seed42.csv", out, fields)


def table3(main_rows):
    out = []
    for universe in UNIVERSE_ORDER:
        candidates = [r for r in main_rows if r["Universe"] == universe]
        candidates.sort(key=lambda r: to_float(r["Return (%)"]), reverse=True)
        for i, row in enumerate(candidates, start=1):
            out.append({"Rank": i, **row})
    fields = ["Universe", "Rank", "Strategy", "Action", "Return (%)", "Sharpe", "Calmar", "Max DD (%)", "Vol. (%)", "Turnover"]
    write_both("Table3_main_model_results_seed42.csv", out, fields)


def table4(main_rows):
    out = []
    for universe in UNIVERSE_ORDER:
        for alg in ["A2C", "DQN", "PPO"]:
            binary = next(r for r in main_rows if r["Universe"] == universe and r["Strategy"] == alg and r["Action"] == "binary")
            granular = next(r for r in main_rows if r["Universe"] == universe and r["Strategy"] == alg and r["Action"] == "granular")
            out.append({
                "Universe": universe,
                "Alg.": alg,
                "Ret. Binary (%)": binary["Return (%)"],
                "Ret. Granular (%)": granular["Return (%)"],
                "Delta Ret.": rounded(to_float(granular["Return (%)"]) - to_float(binary["Return (%)"])),
                "Sharpe Binary": binary["Sharpe"],
                "Sharpe Granular": granular["Sharpe"],
                "Delta Sharpe": rounded(to_float(granular["Sharpe"]) - to_float(binary["Sharpe"])),
                "DD Binary (%)": binary["Max DD (%)"],
                "DD Granular (%)": granular["Max DD (%)"],
                "Turn. Binary": binary["Turnover"],
                "Turn. Granular": granular["Turnover"],
            })
    fields = ["Universe", "Alg.", "Ret. Binary (%)", "Ret. Granular (%)", "Delta Ret.", "Sharpe Binary", "Sharpe Granular", "Delta Sharpe", "DD Binary (%)", "DD Granular (%)", "Turn. Binary", "Turn. Granular"]
    write_both("Table4_binary_vs_granular_action_space.csv", out, fields)


def table5():
    rows = read_csv(SOURCE / "robustness_stats_by_model.csv")
    out = []
    for row in rows:
        short = FOLDER_TO_LABEL[row["universe"]][1]
        out.append({
            "Universe": short,
            "Alg.": row["algo"],
            "Action": row["action_space"],
            "n": row["n_seeds"],
            "Seeds": row["seeds"],
            "Ret. M (%)": pct(row["total_return_mean"]),
            "Ret. SD": rounded(to_float(row["total_return_std"]) * 100),
            "Ret. Min": pct(row["total_return_min"]),
            "Ret. Max": pct(row["total_return_max"]),
            "Sharpe M": rounded(row["sharpe_mean"]),
            "DD M (%)": pct(row["max_drawdown_mean"]),
            "Turn. M": rounded(row["total_turnover_mean"], 2),
        })
    out.sort(key=lambda r: (sort_universe_key(r["Universe"]), r["Alg."], r["Action"]))
    fields = ["Universe", "Alg.", "Action", "n", "Seeds", "Ret. M (%)", "Ret. SD", "Ret. Min", "Ret. Max", "Sharpe M", "DD M (%)", "Turn. M"]
    write_both("Table5_updated_robustness_stats.csv", out, fields)


def appendix_tables():
    seed_rows = read_csv(SOURCE / "robustness_seed_check.csv")
    a1 = []
    for row in seed_rows:
        short = FOLDER_TO_LABEL[row["universe"]][1]
        missing = row.get("missing_expected_seeds", "") or "None"
        a1.append({
            "Universe": short,
            "Algorithm": row["algo"],
            "Action space": row["action_space"],
            "n seeds": row["n_seeds"],
            "Completed seeds": row["seeds"],
            "Missing seeds": missing,
            "Status": "Complete" if missing == "None" else "Incomplete",
        })
    a1.sort(key=lambda r: (sort_universe_key(r["Universe"]), r["Algorithm"], r["Action space"]))
    fields_a1 = ["Universe", "Algorithm", "Action space", "n seeds", "Completed seeds", "Missing seeds", "Status"]
    write_both("Appendix_Table_A1_seed_completion_check.csv", a1, fields_a1)

    a2 = [
        {"Manuscript label": "Baseline 14-Asset Universe", "Earlier label": "Original 14", "Data folder": "data_original14_recent", "Configuration file": "assets_original_14.csv"},
        {"Manuscript label": "Broad 20-Asset Universe", "Earlier label": "Expanded 20", "Data folder": "data_expanded20_recent", "Configuration file": "assets_expanded_20.csv"},
        {"Manuscript label": "Payment-Coin 6-Asset Universe", "Earlier label": "Bitcoin/payment 6", "Data folder": "data_bitcoin_payment6_recent", "Configuration file": "assets_bitcoin_payment_6.csv"},
        {"Manuscript label": "Layer-1 Platform 9-Asset Universe", "Earlier label": "Layer-1 9", "Data folder": "data_layer1_9_recent", "Configuration file": "assets_layer1_9.csv"},
    ]
    fields_a2 = ["Manuscript label", "Earlier label", "Data folder", "Configuration file"]
    write_both("Appendix_Table_A2_universe_label_crosswalk.csv", a2, fields_a2)


def main():
    main_rows = load_main_rows()
    table1()
    table2(main_rows)
    table3(main_rows)
    table4(main_rows)
    table5()
    appendix_tables()
    print(f"Wrote tables to {OUT_TABLES}")
    print(f"Wrote mirrored tables to {OUT_DATA_TABLES}")


if __name__ == "__main__":
    main()
