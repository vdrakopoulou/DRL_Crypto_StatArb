from __future__ import annotations

import csv
from pathlib import Path
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "results" / "tables"
FIGS = ROOT / "results" / "figures"
FIGS.mkdir(parents=True, exist_ok=True)


def read_rows(name: str):
    with (TABLES / name).open(newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def to_float(x):
    return float(x) if x not in (None, "") else 0.0


def save_current(path: Path):
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def figure3():
    rows = read_rows("Table2_best_strategy_by_universe_seed42.csv")
    labels = [r["Asset universe"].replace("-Asset Universe", "").replace(" Universe", "") for r in rows]
    values = [to_float(r["Return (%)"]) for r in rows]
    plt.figure(figsize=(8, 4.8))
    plt.bar(labels, values)
    plt.axhline(0, linewidth=0.8)
    plt.ylabel("Total return (%)")
    plt.title("Best strategy total return by asset universe")
    plt.xticks(rotation=25, ha="right")
    save_current(FIGS / "figure3_best_total_return_by_universe.png")


def figure4():
    rows = read_rows("Table2_best_strategy_by_universe_seed42.csv")
    labels = [r["Asset universe"].replace("-Asset Universe", "").replace(" Universe", "") for r in rows]
    ret = [to_float(r["Return (%)"]) for r in rows]
    dd = [to_float(r["Max DD (%)"]) for r in rows]
    plt.figure(figsize=(8, 4.8))
    plt.scatter(dd, ret)
    for label, x, y in zip(labels, dd, ret):
        plt.annotate(label, (x, y), xytext=(4, 4), textcoords="offset points", fontsize=8)
    plt.axhline(0, linewidth=0.8)
    plt.axvline(0, linewidth=0.8)
    plt.xlabel("Maximum drawdown (%)")
    plt.ylabel("Total return (%)")
    plt.title("Return and drawdown profile of best strategies")
    save_current(FIGS / "figure4_return_drawdown_best_strategies.png")


def figure5():
    rows = read_rows("Table4_binary_vs_granular_action_space.csv")
    labels = [f"{r['Universe']}\n{r['Alg.']}" for r in rows]
    values = [to_float(r["Delta Ret."]) for r in rows]
    plt.figure(figsize=(11, 5.6))
    plt.bar(range(len(values)), values)
    plt.axhline(0, linewidth=0.8)
    plt.ylabel("Granular minus binary return difference (percentage points)")
    plt.title("Granular-minus-binary return difference by model and universe")
    plt.xticks(range(len(labels)), labels, rotation=45, ha="right", fontsize=8)
    save_current(FIGS / "figure5_granular_minus_binary_return_delta.png")


def figure6():
    rows = read_rows("Table5_updated_robustness_stats.csv")
    labels = [f"{r['Universe']}\n{r['Alg.']} {r['Action']}" for r in rows]
    mins = [to_float(r["Ret. Min"]) for r in rows]
    maxs = [to_float(r["Ret. Max"]) for r in rows]
    means = [to_float(r["Ret. M (%)"]) for r in rows]
    y = list(range(len(rows)))
    plt.figure(figsize=(8, 4.8))
    for i, (lo, hi, mean) in enumerate(zip(mins, maxs, means)):
        plt.plot([lo, hi], [i, i], marker="|")
        plt.plot(mean, i, marker="o")
    plt.axvline(0, linewidth=0.8)
    plt.yticks(y, labels, fontsize=8)
    plt.xlabel("Total return across robustness seeds (%)")
    plt.title("Return ranges across robustness seeds")
    save_current(FIGS / "figure6_robustness_return_ranges.png")


def main():
    figure3()
    figure4()
    figure5()
    figure6()
    print(f"Wrote figures to {FIGS}")


if __name__ == "__main__":
    main()
