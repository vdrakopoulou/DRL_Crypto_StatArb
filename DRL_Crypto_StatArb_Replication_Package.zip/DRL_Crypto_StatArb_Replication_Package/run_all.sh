#!/usr/bin/env bash
set -euo pipefail
python code/00_validate_inputs.py
python code/02_recreate_tables.py
python code/03_make_figures.py
python code/04_validate_results.py
