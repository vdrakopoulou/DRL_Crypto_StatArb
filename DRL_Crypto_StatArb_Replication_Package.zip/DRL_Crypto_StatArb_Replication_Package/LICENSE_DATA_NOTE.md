# License and data note

No raw Binance market data are bundled in this package. The included downloader script is provided for reproducibility convenience. Users should verify that their use of downloaded market data complies with the source data provider's terms and their institution's requirements.
