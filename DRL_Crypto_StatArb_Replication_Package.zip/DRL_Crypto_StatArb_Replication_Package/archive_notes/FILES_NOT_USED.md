# Files not used in the clean replication package

This package intentionally excludes older/conflicting output files that caused confusion during manuscript drafting.

Do not use these as manuscript sources unless you are auditing earlier runs:

- `paper_outputs.zip`
- `all_model_summaries.csv`
- individual summary CSV files extracted from older `paper_outputs.zip`
- `best_drl_by_universe_all4_consistent.csv` as the main result table, because it reports best DRL only and not the best overall strategy
- old pasted draft text files
- render/contact-sheet preview folders

The trusted main result source is `data/source_outputs/modeling_comparison_summary.csv`.
