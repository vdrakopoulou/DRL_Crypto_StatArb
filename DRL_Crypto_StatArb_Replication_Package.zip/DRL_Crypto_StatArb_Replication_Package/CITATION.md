# Citation and reference note

When describing the methods in the manuscript, cite the relevant methodological literature in the text, including cointegration/statistical arbitrage, reinforcement learning, and DRL robustness where appropriate.

This replication package itself contains saved result summaries, scripts to recreate manuscript tables and figures, and data-acquisition scaffolding.
