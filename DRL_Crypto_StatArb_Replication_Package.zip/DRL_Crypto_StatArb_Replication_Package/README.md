# DRL Cryptocurrency Statistical Arbitrage Replication Package

This package contains the data artifacts, code, and results needed to reproduce the manuscript tables and figures for the cointegration-based DRL cryptocurrency statistical-arbitrage study.

## Package scope

This package reproduces the manuscript tables and figures from saved model-summary outputs. The raw Binance 30-minute OHLCV files and trained DRL model checkpoint files were not present in the uploaded materials, so they are not bundled here. A downloader scaffold is included to reconstruct raw OHLCV data from Binance Public Data.

## Folder structure

```text
DRL_Crypto_StatArb_Replication_Package/
  README.md
  requirements.txt
  environment.yml
  run_all.sh
  run_all.bat
  code/
    00_validate_inputs.py
    01_download_binance_klines.py
    02_recreate_tables.py
    03_make_figures.py
    04_validate_results.py
    helpers.py
  config/
    study_config.yaml
    universe_crosswalk.csv
    asset_universes/
  data/
    raw_ohlcv/
    source_outputs/
    final_tables/
  results/
    tables/
    figures/
    docx/
    logs/
  paper_support/
  archive_notes/
```

## Reproduction steps

From the package root, run:

```bash
python code/00_validate_inputs.py
python code/02_recreate_tables.py
python code/03_make_figures.py
python code/04_validate_results.py
```

On macOS/Linux, you can also run:

```bash
bash run_all.sh
```

On Windows, run:

```bat
run_all.bat
```

## Expected outputs

The scripts recreate these files under `results/tables/` and mirror them under `data/final_tables/`:

- `Table1_asset_universes.csv`
- `Table2_best_strategy_by_universe_seed42.csv`
- `Table3_main_model_results_seed42.csv`
- `Table4_binary_vs_granular_action_space.csv`
- `Table5_updated_robustness_stats.csv`
- `Appendix_Table_A1_seed_completion_check.csv`
- `Appendix_Table_A2_universe_label_crosswalk.csv`

The figure script recreates these files under `results/figures/`:

- `figure3_best_total_return_by_universe.png`
- `figure4_return_drawdown_best_strategies.png`
- `figure5_granular_minus_binary_return_delta.png`
- `figure6_robustness_return_ranges.png`

## Key expected values

The validation script checks these key manuscript values:

- Baseline 14 best seed-42 return: 30.24%.
- Broad 20 best seed-42 return: 3.25%.
- Payment-Coin 6 best seed-42 return: 32.26%.
- Layer-1 Platform 9 best seed-42 return: -7.83%.
- Payment-Coin 6 DQN binary robustness mean return: 16.50%.

## Raw data reconstruction

To list Binance Public Data URLs without downloading:

```bash
python code/01_download_binance_klines.py --all --dry-run
```

To download monthly 30-minute USDT spot kline files for all configured universes:

```bash
python code/01_download_binance_klines.py --all --start 2023-01 --end 2025-05
```

Raw files should be stored under `data/raw_ohlcv/`. See `data/raw_ohlcv/README_RAW_DATA.md` for the expected layout.

## Notes on result provenance

- `data/source_outputs/modeling_comparison_summary.csv` is the trusted source for the main seed-42 model comparison.
- `data/source_outputs/robustness_stats_by_model.csv` is the trusted source for the updated robustness table.
- `data/source_outputs/robustness_seed_check.csv` confirms the robustness seed completion status.
- Older/conflicting summary files are not used in this package.

## Manuscript support files

`results/docx/` contains the APA table/figure consultation pack and native Word equation objects for Sections 4.5 and 4.6.

## Suggested citation note for the manuscript

Use this package to document replication materials, result tables, figure generation, and data acquisition steps. The package is designed for transparent table/figure replication from saved model-summary outputs.
